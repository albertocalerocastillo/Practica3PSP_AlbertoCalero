package es.studium.practica;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

import javax.swing.JOptionPane;

public class Cliente implements ActionListener
{
	static final String HOST = "localhost";
	static final int PUERTO = 6000;

	public Juego j;
	public Espera e;
	public Ranking2 r;
	public Mano m;

	static String jugadores = "";
	static String apuestas = "";
	static String puntos = "";
	
	public Cliente()
	{
		this.j = new Juego();
		this.e = new Espera();
		this.r = new Ranking2();

		this.m = new Mano();

		activarListenerJuego();

		this.j.setVisible(true);
	}

	public static void main(String[] arg)
	{			
		new Cliente();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.j.btnPiedra)
		{
			generarMano(0);
		}
		else if(e.getSource() == this.j.btnPapel)
		{
			generarMano(1);
		}		
		else if(e.getSource() == this.j.btnTijeras)
		{
			generarMano(2);
		}
		else if(e.getSource() == this.j.btnLagarto)
		{
			generarMano(3);
		}
		else if(e.getSource() == this.j.btnSpock)
		{
			generarMano(4);
		}
		else if(e.getSource() == this.e.btnEspera)
		{
			this.e.btnEspera.removeActionListener(this);
			this.e.setVisible(false);
		}
	}

	private void generarMano(int apuesta) {
		if(this.j.txtUsuario.getText().length() == 0)
		{	
			this.e.lblMensaje.setText("Debe escribir su nombre");
			this.e.btnEspera.setText("Cancelar");
			this.e.btnEspera.setActionCommand("Cancel");
			this.e.btnEspera.addActionListener(this);
			this.e.setVisible(true);
		}
		else {
			try
			{
				System.out.println("Iniciando programa cliente..");
				try (Socket cliente = new Socket(HOST, PUERTO)) {
					ObjectOutputStream salida = new ObjectOutputStream(cliente.getOutputStream());
					this.m = new Mano (this.j.txtUsuario.getText(), apuesta);
					desactivarListenerJuego();
					this.e.lblMensaje.setText("Esperando a los dem�s jugadores...");
					this.e.btnEspera.setText("OK");
					this.e.btnEspera.setActionCommand("OK");
					this.e.btnEspera.addActionListener(this);
					this.e.setVisible(true);
					salida.writeObject(this.m);

					ObjectInputStream entrada = new ObjectInputStream(cliente.getInputStream());
					try {
						List<String> arr = (List<String>) entrada.readObject();

						//LAS CADENAS QUE HAY QUE METER EN LA VISTA QUE QUEDA
						jugadores = arr.get(0);
						apuestas = arr.get(1);
						puntos = arr.get(2);

						
						this.e.btnEspera.removeActionListener(this);
						this.e.setVisible(false);
						this.j.setVisible(false);
						//this.r.setVisible(true);
						Ranking2.main(null);
						

					} catch (ClassNotFoundException e1) {
						e1.printStackTrace();
					}
				}
			}
			catch (IOException ex)
			{
				ex.printStackTrace();
				JOptionPane.showMessageDialog(null, "Imposible conectar con el servidor \n" + ex.getMessage(), "<<Mensaje de Error:1>>", JOptionPane.ERROR_MESSAGE);
				System.exit(0);
			}
		}
	}

	private void activarListenerJuego()
	{
		this.j.btnPiedra.addActionListener(this);
		this.j.btnPapel.addActionListener(this);
		this.j.btnTijeras.addActionListener(this);
		this.j.btnLagarto.addActionListener(this);
		this.j.btnSpock.addActionListener(this);
	}

	private void desactivarListenerJuego()
	{
		this.j.btnPiedra.removeActionListener(this);
		this.j.btnPapel.removeActionListener(this);
		this.j.btnTijeras.removeActionListener(this);
		this.j.btnLagarto.removeActionListener(this);
		this.j.btnSpock.removeActionListener(this);
	}
}