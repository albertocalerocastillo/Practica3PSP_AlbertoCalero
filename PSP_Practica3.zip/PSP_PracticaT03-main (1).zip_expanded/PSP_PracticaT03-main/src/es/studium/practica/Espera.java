package es.studium.practica;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;

public class Espera extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	public JButton btnEspera; 
	public JLabel lblMensaje;
	
	public Espera() {
		setTitle("Esperando....");
		setBounds(100, 100, 450, 140);
		setResizable(false);
		setLocationRelativeTo(null);  
		
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			lblMensaje = new JLabel("");
			lblMensaje.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblMensaje.setBounds(27, 31, 365, 33);
			contentPanel.add(lblMensaje);
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				btnEspera = new JButton();
				buttonPane.add(btnEspera);
				getRootPane().setDefaultButton(btnEspera);
			}
		}
		
	}

}
