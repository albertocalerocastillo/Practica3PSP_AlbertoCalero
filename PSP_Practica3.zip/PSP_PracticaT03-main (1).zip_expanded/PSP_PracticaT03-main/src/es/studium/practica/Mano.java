package es.studium.practica;
import java.io.Serializable;
import java.util.Comparator;

public class Mano implements Serializable, Comparator<Mano> {

	private static final long serialVersionUID = 1L;
	private String nombre;
	private int apuesta;
	private int puntos;

	public Mano()
	{
		this.nombre = "";
		this.apuesta = 0;
		this.puntos = 0;
	}

	public 	Mano(String n, int a)
	{
		this.nombre = n;
		this.apuesta = a;
		this.puntos = 0;
	}

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getApuesta() {
		return apuesta;
	}
	public void setApuesta(int apuesta) {
		this.apuesta = apuesta;
	}

	public int getPuntos() {
		return puntos;
	}

	public void setPuntos(int victorias) {
		this.puntos = victorias;
	}

	@Override
	public int compare(Mano m1, Mano m2) {
		int res;
		if(m1.getPuntos() == m2.getPuntos())
		{
			res = 0;
		}else if(m1.getPuntos() > m2.getPuntos()){
			res = -1;
		}
		else {
			res = 1;
		}
		return res;
	}
}
