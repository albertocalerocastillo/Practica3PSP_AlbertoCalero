package es.studium.practica;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

public class Hilo extends Thread {
	Socket cliente;
	ObjectInputStream entrada;
	Mano m;
	
	public Hilo(Socket s) throws IOException 
	{
		this.cliente = s;
		this.entrada = new ObjectInputStream(cliente.getInputStream());
		this.m = null;
	}
	
	public void run() {
		try {
			this.m=(Mano) this.entrada.readObject();
			Servidor.setMano(this.m);
			//this.entrada.close();
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}
}
