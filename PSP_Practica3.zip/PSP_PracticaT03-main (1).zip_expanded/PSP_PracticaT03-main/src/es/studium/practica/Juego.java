package es.studium.practica;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Juego extends JFrame {

	private static final long serialVersionUID = 1L;
	public JTextField txtUsuario = new JTextField();
	private JLabel lblNewLabel = new JLabel("Usuario:");
	public JButton btnPiedra = new JButton("");
	public JButton btnPapel = new JButton("");
	public JButton btnTijeras = new JButton("");
	public JButton btnLagarto = new JButton("");
	public JButton btnSpock = new JButton("");

	public Juego() {
		super("JUEGO");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
		setSize(525,455);
		setResizable(false);
		setLocationRelativeTo(null);  
		
		getContentPane().setLayout(null);

		txtUsuario = new JTextField();
		txtUsuario.setBounds(223, 58, 102, 20);
		txtUsuario.setColumns(10);
		getContentPane().add(txtUsuario);

		lblNewLabel = new JLabel("Usuario:");
		lblNewLabel.setBounds(128, 61, 85, 14);
		getContentPane().add(lblNewLabel);
		
		btnPiedra = new JButton();
		btnPiedra.setBounds(65, 114, 96, 96);
		btnPiedra.setIcon(new ImageIcon(Juego.class.getResource("/es/studium/practica/piedra.png")));
		getContentPane().add(btnPiedra);
		
		btnPapel = new JButton();
		btnPapel.setBounds(205, 114, 96, 96);
		btnPapel.setIcon(new ImageIcon(Juego.class.getResource("/es/studium/practica/papel.png")));
		getContentPane().add(btnPapel);
		

		btnTijeras = new JButton("");
		btnTijeras.setBounds(346, 114, 96, 96);
		btnTijeras.setIcon(new ImageIcon(Juego.class.getResource("/es/studium/practica/tijeras.png")));		
		getContentPane().add(btnTijeras);

		btnLagarto = new JButton("");
		btnLagarto.setBounds(128, 260, 96, 96);
		btnLagarto.setIcon(new ImageIcon(Juego.class.getResource("/es/studium/practica/lagarto.png")));
		getContentPane().add(btnLagarto);

		btnSpock = new JButton("");
		btnSpock.setIcon(new ImageIcon(Juego.class.getResource("/es/studium/practica/spock.png")));
		btnSpock.setBounds(281, 260, 96, 96);		
		getContentPane().add(btnSpock);
		
		JLabel lblPiedra = new JLabel("Piedra");
		lblPiedra.setBounds(65, 216, 85, 14);
		getContentPane().add(lblPiedra);
		
		JLabel lblPapel = new JLabel("Papel");
		lblPapel.setBounds(205, 217, 85, 14);
		getContentPane().add(lblPapel);
		
		JLabel lblTijeras = new JLabel("Tijeras");
		lblTijeras.setBounds(346, 220, 85, 14);
		getContentPane().add(lblTijeras);
		
		JLabel lblLagarto = new JLabel("Lagarto");
		lblLagarto.setBounds(128, 366, 85, 14);
		getContentPane().add(lblLagarto);
		
		JLabel lblSpock = new JLabel("Spock");
		lblSpock.setBounds(281, 366, 85, 14);
		getContentPane().add(lblSpock);
	}
}
