package es.studium.practica;


import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Servidor
{
	static final int PUERTO = 6000;

	static final int MAXIMO = 2;
	static int CONEXIONES = 0;

	static List<Hilo> hilos = new ArrayList<Hilo>();
	static List<Mano> manos = new ArrayList<Mano>();
	static List<Socket> clientes = new ArrayList<Socket>();

	public static void main(String[] arg)
	{
		try
		{
			ServerSocket servidor = new ServerSocket(PUERTO);
			System.out.println("Servidor iniciado en el puerto: " + PUERTO);

			while(CONEXIONES<MAXIMO)
			{
				Socket cliente = servidor.accept();
				hilos.add(new Hilo(cliente));
				clientes.add(cliente);
				hilos.get(CONEXIONES).start();
				CONEXIONES++;
				System.out.println("N�mero de jugadores conectados: " + CONEXIONES);
			}

			for(int i = 0;i<hilos.size();i++)
			{
				try 
				{
					hilos.get(i).join();
				} catch (InterruptedException e) 
				{
					e.printStackTrace();
				}
			}

			if(!servidor.isClosed())
			{
				try
				{
					System.err.println("M�ximo N� de jugadores alcanzado: " + CONEXIONES);

					for(int i = 0; i<manos.size();i++)
					{
						int m1 = manos.get(i).getApuesta();

						for(int j = 0; j<manos.size();j++)
						{
							int m2 = manos.get(j).getApuesta();				

							//casos de victoria del jugador 1. Se le suma un punto
							if((m1 == 2 && m2 == 1) ||
									(m1 == 1 && m2 == 0) ||
									(m1 == 0 && m2 == 3) ||
									(m1 == 3 && m2 == 4) ||
									(m1 == 4 && m2 == 2) ||
									(m1 == 2 && m2 == 3) ||
									(m1 == 3 && m2 == 1) ||
									(m1 == 1 && m2 == 4) ||
									(m1 == 4 && m2 == 0) ||
									(m1 == 0 && m2 == 2))
							{
								manos.get(i).setPuntos(manos.get(i).getPuntos() + 1);
							}
							//Casos de derrota del jugador 1. se le resta un punto
							else if(m1 != m2)
							{
								manos.get(i).setPuntos(manos.get(i).getPuntos() - 1);
							}
						}
					}

					//Ordenamos las manos
					Collections.sort(manos, new Mano());

					String jugadores = "";
					String apuestas = "";
					String puntos = "";
					
					for(int i = 0; i<manos.size();i++)
					{
						System.out.println(manos.get(i).getNombre() + " sac� piedra y tiene " + manos.get(i).getPuntos() + " puntos");
						jugadores += manos.get(i).getNombre() + "<br/>";
						int apuestaMano = manos.get(i).getApuesta();
						if(apuestaMano == 0) 
						{
							apuestas += " Piedra <br/>";	
						}
						else if(apuestaMano == 1)
						{
							apuestas += " Papel <br/>";
						}
						else if(apuestaMano == 2)
						{
							apuestas += " Tijeras <br/>";
						}
						else if(apuestaMano == 3)
						{
							apuestas += " Lagarto <br/>";
						}
						else if(apuestaMano == 4)
						{
							apuestas += " Spock <br/>";
						}
						
						//apuestas += manos.get(i).getApuesta() + "<br/>";
						puntos += manos.get(i).getPuntos() + "<br/>";
					}

					List<String> arr = new ArrayList<String>();

					arr.add("<html>" + jugadores + "</html>");
					arr.add("<html>" + apuestas + "</html>");
					arr.add("<html>" + puntos + "</html>");

					for(int i = 0; i<clientes.size();i++)
					{
						Socket c = clientes.get(i);
						ObjectOutputStream salida = new ObjectOutputStream(c.getOutputStream());
						salida.writeObject(arr);
					}

					servidor.close();
				}
				catch (IOException ex)
				{
					ex.printStackTrace();
				}
			}
			else
			{
				System.out.println("Servidor finalizado...");
			}
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	public static void setMano(Mano m)
	{
		manos.add(m);
	}
	public static String detectarApuesta(int apuesta) {
		String a = "";
		switch (apuesta) {
		case 0: {
			a = "PIEDRA";
			break;
		}					
		case 1: {
			a =  "PAPEL";
			break;
		}
		case 2: {
			a =  "TIJERAS";
			break;
		}
		case 3: {
			a =  "LAGARTO";
			break;
		}
		default:
			a =  "SPOCK";
			break;
		}
		return a;
	}
}
