package es.studium.practica;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

public class Ranking2 extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	
	String jugadoresLista = "";
	String PuntosLista = "";
	String ApuestaLista = "";
	//public Cliente c;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ranking2 frame = new Ranking2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ranking2() {
		//this.c = new Cliente();
		jugadoresLista = Cliente.jugadores.toString();
		PuntosLista = Cliente.puntos.toString();
		ApuestaLista = Cliente.apuestas.toString();
		
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("RANKING");
		lblNewLabel.setBounds(172, 26, 91, 30);
		contentPane.add(lblNewLabel);
		
		JLabel NombreJugadores = new JLabel(jugadoresLista);
		NombreJugadores.setBounds(33, 104, 101, 149);
		contentPane.add(NombreJugadores);
		
		JLabel PuntosJugadores = new JLabel(PuntosLista);
		PuntosJugadores.setBounds(167, 104, 101, 149);
		contentPane.add(PuntosJugadores);
		
		JLabel ApuestaJugadores = new JLabel(ApuestaLista);
		ApuestaJugadores.setBounds(301, 104, 101, 149);
		contentPane.add(ApuestaJugadores);
		
		JLabel Puntos = new JLabel("Puntos");
		Puntos.setBounds(186, 81, 45, 13);
		contentPane.add(Puntos);
		
		JLabel jugador = new JLabel("Jugadores");
		jugador.setBounds(49, 81, 59, 13);
		contentPane.add(jugador);
		
		JLabel Apuesta = new JLabel("Apuesta");
		Apuesta.setBounds(305, 81, 45, 13);
		contentPane.add(Apuesta);
	}
}
